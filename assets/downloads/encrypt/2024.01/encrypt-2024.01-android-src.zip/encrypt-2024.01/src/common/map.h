/*
 * Common code for dealing with maps.
 * Copyright © 2022-2024, albinoloverats ~ Software Development
 * email: webmaster@albinoloverats.net
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef _COMMON_MAP_H_
#define _COMMON_MAP_H_

/*!
 * \file    map.h
 * \author  albinoloverats ~ Software Development
 * \date    2022-2024
 * \brief   Common map code shared between projects
 *
 * Common map implementation.
 */

#include <stddef.h>
#include <stdbool.h>

#include "common.h"
#include "list.h"
#include "pair.h"

typedef void * MAP; /*!< The user visible MAP type */

/*!
 * \brief         Create a new map
 * \param[in]  c  Function to compare keys during insertion
 * \param[in]  f  Whether to call free() when replacing/removing entries
 * \param[in]  s  Whether the keys are sorted
 * \param[in]  o  Whether to overwrite existing entries when adding
 * \return        A new map
 *
 * Create a new map instance; all further operations are then performed
 * against this handle. Returns NULL on error.
 *
 * Note: if o==true and f==false you may leak memory!
 */
#define map_default() map_init(NULL, true, false, false)

extern MAP map_init(int c(const void *, const void *), bool f, bool s, bool o);

/*!
 * \brief         Destroy a map
 * \param[in]  h  A pointer to a map to destroy
 *
 * Destroy a previously created map when it is no longer needed. Free
 * the memory and sets h to NULL so all subsequent calls to MAP
 * functions will not result in undefined behaviour. If called with f as
 * false then keys and values items will not be freed.
 */
extern void map_deinit(MAP h) __attribute__((nonnull(1)));

/*!
 * \brief         Get the number of entries in the map
 * \param[in]  h  A pointer to the map
 * \return        The number of entries in the map
 *
 * Get the number of entries in the map.
 */
extern size_t map_size(MAP h) __attribute__((nonnull(1)));

/*!
 * \brief         Add an entry to the map
 * \param[in]  h  A pointer to the map
 * \param[in]  k  The key of the entry to add
 * \param[in]  v  The value of the entry to add
 * \reutrn        Whether the entry was added
 *
 * Add a new entry to the map. If the map is sorted then the entry will
 * be inserted based on the results of the compare function, otherwise
 * it will be appended. If the key already exists, whether it is
 * overwritten depends on how the map was initialised. Returns true if
 * the key/value are added/replaced, false otherwise.
 */
extern bool map_add(MAP h, const void *k, const void *v) __attribute__((nonnull(1, 2, 3)));

/*!
 * \brief         Get a value from the map
 * \param[in]  h  A pointer to the map
 * \param[in]  k  The key of the value to get
 * \return        The value for the given key
 *
 * Retrieve the value for the given key from within the map.
 */
extern const void *map_get(MAP h, const void *k) __attribute__((nonnull(1, 2)));

/*!
 * \brief         Check if the map contains the key
 * \param[in]  h  A pointer to the map
 * \param[in]  k  The key to check for
 * \return        True if the map contains a value for the given key,
 *                false otherwise
 *
 * Check whether the map contains the key. If a comparator was set
 * during initialisation then that is used instead of just comparing the
 * pointer.
 */
extern bool map_contains(MAP h, const void *k) __attribute__((nonnull(1, 2)));

/*!
 * \brief         Remove a key/value from the map
 * \param[in]  h  A pointer to the map
 * \param[in]  k  The key of the entry to remove
 * \return        The value that was removed, or NULL
 *
 * Remove the given key/value from the map. The value is returned to
 * allow the user to free it if necessary. If the ey was not found in
 * the map then the function returns NULL. If a comparator was set
 * during initialisation then that is used instead of just comparing the
 * pointer.
 */
extern const void *map_remove(MAP h, const void *k) __attribute__((nonnull(1, 2)));

/*!
 * \brief         Set the map up for iterating
 * \param[in]  h  A pointer to the map
 * \return        An iterator for the map
 *
 * Set the map up to be iterated over. The iterator should be freed
 * after use.
 */
extern ITER map_iterator(MAP h) __attribute__((nonnull(1)));

/*!
 * \brief         Get the next entryin the map
 * \param[in]  h  A pointer to the iterator
 * \return        The next entry in the map
 *
 * Allow iterating through the map, this returns pair of pointers for
 * the next key/value entry.
 */
extern const pair_object_t *map_get_next(ITER h) __attribute__((nonnull(1)));

/*!
 * \brief         Indicates if there is another item in the map
 * \param[in]  h  A pointer to the iterator
 * \return        Returns true if there is another entry
 *
 * Allow iterating through the map, this returns whether there is
 * another entry.
 */
extern bool map_has_next(ITER h) __attribute__((nonnull(1)));

/*!
 * \brief         Call the given function for each item in the map
 * \param[in]  h  A pointer to the map
 * \param[in]  f  The function to call
 *
 * Iterate through the map, calling the given function for each item.
 */
extern void map_for_each(MAP h, void f(const void *, const void *)) __attribute__((nonnull(1, 2)));

/*!
 * \brief         Add comparator to the map
 * \param[in]  h  A pointer to the map
 * \param[in]  c  The comparator to add
 *
 * Add a comparator to the map so that items can be compared.
 */
extern void map_add_comparator(MAP h, int c(const void *, const void *)) __attribute__((nonnull(1, 2)));

#endif /* _COMMON_MAP_H_ */
